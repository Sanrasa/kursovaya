#include "fileconvert.h"

FileConvert::FileConvert(QObject *parent)
    : QObject{parent}
{

}

QImage FileConvert::Convert(QImage view)
{
    for (int w = 0; w<view.rect().right();w++)
           for (int h = 0; h<view.rect().bottom();h++)
           {
              QColor col(view.pixel(w,h));
              int r = col.red();
              int g = col.green();
              int b = col.blue();
              r = 255 - r;
              g = 255 - g;
              b = 255 - b;
              col.setRgb(r,g,b, 0);
              view.setPixel(w,h,col.rgb());
           }
    return(view);
}
