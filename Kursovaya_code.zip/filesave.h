#ifndef FILESAVE_H
#define FILESAVE_H

#include <QObject>
#include <QFileInfo>
#include <QString>

class FileSave : public QObject
{
    Q_OBJECT
public:
    explicit FileSave(QObject *parent = nullptr);

    QString saveFileName(QFileInfo loc);

private:
    QString File_Name;
};

#endif // FILESAVE_H
