#include "filesave.h"

FileSave::FileSave(QObject *parent)
    : QObject{parent}
{

}

QString FileSave::saveFileName(QFileInfo loc)
{
    QString tempFileName = loc.fileName();
    QString File_Name = loc.absolutePath().replace(tempFileName.lastIndexOf(".png"), 4," (negative).png")
                                          .replace(tempFileName.lastIndexOf(".jpeg"), 5," (negative).png")
                                          .replace(tempFileName.lastIndexOf(".jpg"), 4," (negative).png");
    return (File_Name);
};
